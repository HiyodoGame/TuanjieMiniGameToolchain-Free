# MiniGame Starter Kit

微信小游戏项目启动套件：预配置模板、核心系统框架与微信 SDK 封装。

## 适用范围

本包为 **MiniGame Toolchain 免费版** 的一部分，包含 编辑器工具与运行时组件。

## 安装

1. 解压分发包。
2. 在 Unity Package Manager 中选择 **Add package from disk...**。
3. 选择本文件夹（包含 `package.json` 的目录）。

## 依赖

- `com.hiyodo.minigametoolchain.core`: `0.1.4`
- `com.qq.weixin.minigame`: `https://gitee.com/wechat-minigame/minigame-tuanjie-transform-sdk.git#v0.1.32`

## 文档与协议

- [更新日志](CHANGELOG.md)
- [许可协议](LICENSE.md)
